# 在服务器上安装图形界面访问Google

## 📋 目标

### 需要完成：
1. **安装Ubuntu图形化界面**（桌面环境）
2. **安装浏览器**（Chrome或Firefox）
3. **配置远程桌面**（VNC或使用Workbench图形化功能）
4. **访问Google Play Console注册**

---

## 🖥️ 步骤1：安装Ubuntu桌面环境

### 在服务器Workbench终端执行：

```bash
# 更新软件包列表
apt update

# 安装Ubuntu桌面环境（这可能需要10-20分钟）
apt install -y ubuntu-desktop-minimal

# 或者安装完整桌面环境（如果需要更多功能）
# apt install -y ubuntu-desktop
```

### 安装过程：
- **下载大小**：约500MB-1GB
- **安装时间**：10-20分钟
- **需要确认**：输入 `y` 确认安装

---

## 🌐 步骤2：安装浏览器

### 安装Chrome浏览器（推荐）：

```bash
# 下载Chrome
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb

# 安装Chrome
apt install -y ./google-chrome-stable_current_amd64.deb

# 清理下载文件
rm google-chrome-stable_current_amd64.deb
```

### 或者安装Firefox浏览器：

```bash
# 安装Firefox
apt install -y firefox
```

---

## 🖥️ 步骤3：配置远程桌面（VNC）

### 安装VNC服务器：

```bash
# 安装VNC服务器
apt install -y tigervnc-standalone-server tigervnc-common

# 安装桌面环境（如果还没有）
apt install -y xfce4 xfce4-goodies
```

### 配置VNC密码：

```bash
# 设置VNC密码（需要输入密码，至少6位）
vncpasswd
```

### 创建VNC启动脚本：

```bash
# 创建启动脚本
mkdir -p ~/.vnc
cat > ~/.vnc/xstartup << 'EOF'
#!/bin/bash
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
/etc/X11/xinit/xinitrc
[ -x /etc/vnc/xstartup ] && exec /etc/vnc/xstartup
[ -r $HOME/.Xresources ] && xrdb $HOME/.Xresources
x-window-manager &
startxfce4 &
EOF

# 设置执行权限
chmod +x ~/.vnc/xstartup
```

### 启动VNC服务器：

```bash
# 启动VNC服务器（端口5901）
vncserver :1 -geometry 1920x1080 -depth 24

# 或者使用其他分辨率
# vncserver :1 -geometry 1280x720 -depth 24
```

---

## 🔧 步骤4：配置防火墙和安全组

### 在服务器上开放VNC端口：

```bash
# 开放VNC端口（5901）
ufw allow 5901/tcp

# 或者开放VNC端口范围（5900-5910）
ufw allow 5900:5910/tcp
```

### 在阿里云控制台配置安全组：

1. **登录阿里云控制台**
2. **进入ECS实例管理**
3. **选择服务器实例**
4. **点击"安全组" → "配置规则"**
5. **添加规则**：
   - **端口范围**：5901/5901
   - **授权对象**：0.0.0.0/0（或你的IP地址）
   - **协议类型**：TCP

---

## 💻 步骤5：使用VNC客户端连接

### 在本地Mac上安装VNC客户端：

#### 选项1：使用内置的"屏幕共享"（推荐）

1. **打开"屏幕共享"应用**（在"应用程序" → "实用工具"）
2. **输入服务器地址**：`vnc://47.243.177.166:5901`
3. **输入VNC密码**（刚才设置的密码）

#### 选项2：使用VNC Viewer

1. **下载VNC Viewer**：https://www.realvnc.com/en/connect/download/viewer/
2. **安装并打开VNC Viewer**
3. **输入服务器地址**：`47.243.177.166:5901`
4. **输入VNC密码**

---

## 🌐 步骤6：访问Google Play Console

### 在VNC连接的图形界面中：

1. **打开Chrome浏览器**
2. **访问Google Play Console**：https://play.google.com/console
3. **登录Google账号**（如果没有，先注册）
4. **完成注册流程**

---

## 🔄 替代方案：使用Workbench图形化功能

### 如果VNC配置复杂，可以使用Workbench的图形化功能：

1. **在阿里云控制台打开Workbench**
2. **选择"图形化桌面"或"VNC"选项**
3. **连接到图形界面**
4. **在图形界面中打开浏览器**

---

## 📝 简化方案：使用命令行浏览器（不推荐）

### 如果图形界面安装有问题，可以使用命令行浏览器：

```bash
# 安装lynx（文本浏览器）
apt install -y lynx

# 访问Google（但无法完成注册，因为需要JavaScript）
lynx https://play.google.com/console
```

**注意**：命令行浏览器无法完成Google Play Console注册，因为需要JavaScript支持。

---

## 🎯 推荐步骤

### 最简单的方法：

1. **安装Ubuntu桌面环境**：`apt install -y ubuntu-desktop-minimal`
2. **安装Chrome**：下载并安装Chrome
3. **使用Workbench的图形化功能**（如果可用）
4. **或者配置VNC**：按照上面的步骤配置

---

## 📝 请告诉我

### 执行安装命令后，请告诉我：

1. **桌面环境是否安装成功？**
   - 是否显示安装完成？

2. **浏览器是否安装成功？**
   - Chrome或Firefox是否可用？

3. **是否要配置VNC？**
   - 或者使用Workbench的图形化功能？

4. **是否成功访问Google？**
   - 能否打开Google Play Console？

---

## 🎯 总结

### 当前状态：
- ⏳ 需要安装图形化界面
- ⏳ 需要安装浏览器
- ⏳ 需要配置远程桌面
- ⏳ 需要访问Google Play Console

### 下一步：
1. **安装Ubuntu桌面环境**：`apt install -y ubuntu-desktop-minimal`
2. **安装Chrome浏览器**：下载并安装
3. **配置VNC或使用Workbench图形化功能**
4. **访问Google Play Console注册**

**请先在服务器上执行安装桌面环境的命令，然后告诉我结果！**

