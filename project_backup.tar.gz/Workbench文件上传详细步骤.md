# Workbench文件上传详细步骤

## 📋 使用Workbench上传video_server.py

### 方法1：使用Workbench文件管理器（推荐）

#### 步骤1：打开文件管理器

1. **登录阿里云Workbench**
2. **连接到服务器**
3. **在Workbench界面中找到"文件"或"文件管理器"按钮**
   - 通常在顶部工具栏
   - 或左侧菜单栏
   - 图标可能是文件夹图标 📁

---

#### 步骤2：导航到目标目录

1. **在文件管理器中**：
   - 导航到 `/root/` 目录
   - 如果 `video_server` 目录不存在，先创建它

2. **创建目录**（如果不存在）：
   - 右键点击 `/root/` 目录
   - 选择"新建文件夹"
   - 输入名称：`video_server`

---

#### 步骤3：上传文件

1. **在文件管理器中**：
   - 进入 `/root/video_server/` 目录

2. **上传文件**：
   - **方法A**：点击"上传"按钮（通常在顶部工具栏）
   - **方法B**：右键点击空白处，选择"上传文件"
   - **方法C**：直接拖拽文件到文件管理器

3. **选择文件**：
   - 选择本地的 `video_server.py` 文件
   - 路径：`/Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905/video_server.py`

4. **等待上传完成**

---

### 方法2：使用终端命令（如果文件上传不可用）

#### 步骤1：在本地查看文件内容

在本地Mac终端执行：

```bash
cat /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905/video_server.py
```

**复制整个文件内容**

---

#### 步骤2：在服务器上创建文件

在服务器Workbench终端执行：

```bash
# 创建目录
mkdir -p /root/video_server

# 创建文件
cat > /root/video_server/video_server.py << 'EOFFILE'
```

**然后粘贴文件内容，最后输入**：
```
EOFFILE
```

---

### 方法3：使用scp（如果SSH可用）

在本地Mac终端执行：

```bash
scp /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905/video_server.py root@47.243.177.166:/root/video_server/
```

**如果提示输入密码**：输入服务器密码

---

## 🔍 Workbench界面说明

### 文件管理器位置

Workbench的文件管理器通常在：

1. **顶部工具栏**：
   - 可能有"文件"、"文件管理"、"文件浏览器"等按钮

2. **左侧菜单栏**：
   - 可能有文件夹图标 📁
   - 点击后打开文件管理器

3. **右键菜单**：
   - 在终端中右键，可能有"打开文件管理器"选项

---

### 上传按钮位置

上传按钮通常在：

1. **文件管理器顶部工具栏**：
   - "上传"按钮
   - 或"Upload"按钮
   - 或上传图标 ⬆️

2. **右键菜单**：
   - 在文件管理器中右键
   - 选择"上传文件"或"Upload"

3. **拖拽上传**：
   - 直接拖拽文件到文件管理器窗口

---

## 📝 详细操作步骤（推荐方法）

### 步骤1：在Workbench中找到文件管理器

1. **查看Workbench界面**
2. **找到文件管理器入口**：
   - 顶部工具栏的"文件"按钮
   - 或左侧菜单的文件夹图标
   - 或右键菜单中的选项

---

### 步骤2：创建目录（如果不存在）

1. **在文件管理器中导航到 `/root/`**
2. **创建 `video_server` 目录**：
   - 右键 → 新建文件夹 → 输入 `video_server`

---

### 步骤3：上传文件

1. **进入 `/root/video_server/` 目录**
2. **点击"上传"按钮**（或右键选择"上传文件"）
3. **选择文件**：
   - 浏览到：`/Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905/video_server.py`
4. **等待上传完成**

---

### 步骤4：验证文件

在服务器Workbench终端执行：

```bash
# 检查文件是否存在
ls -la /root/video_server/video_server.py

# 查看文件内容（前几行）
head -20 /root/video_server/video_server.py
```

---

## 🔄 如果Workbench没有文件上传功能

### 替代方法：使用终端创建文件

#### 步骤1：在本地复制文件内容

在本地Mac终端执行：

```bash
# 查看文件路径
cat /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905/video_server.py | wc -l
```

**记录文件行数**（用于验证）

---

#### 步骤2：在服务器上创建文件

在服务器Workbench终端执行：

```bash
# 创建目录
mkdir -p /root/video_server

# 创建文件（我会提供完整内容）
cat > /root/video_server/video_server.py << 'EOFFILE'
```

**然后我会提供完整的文件内容让你粘贴**

---

## 💡 提示

### 如果找不到文件上传功能：

1. **检查Workbench版本**：可能需要更新
2. **使用终端方法**：直接创建文件
3. **使用scp**：如果SSH可用

---

## 🎯 推荐操作

### 最简单的方法：

1. **在Workbench中找到文件管理器**
2. **导航到 `/root/video_server/`**
3. **点击上传按钮**
4. **选择 `video_server.py` 文件**

---

**如果找不到文件上传功能，告诉我，我会提供终端创建文件的方法！** 🚀

