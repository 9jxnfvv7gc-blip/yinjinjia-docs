package com.example.video_music_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
