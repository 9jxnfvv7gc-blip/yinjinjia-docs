# 退出less并继续测试

## 🔍 当前状态

你正在 `less` 分页器中（帮助页面）。

---

## 🚀 操作步骤

### 步骤1：退出less

在终端中：

1. **按 `q` 键**（退出less）
2. 应该会返回到正常的命令提示符：`root@iZj6cg78ov73x6cxbephc1Z:~/video_server#`

---

### 步骤2：检查服务状态

退出less后，在Workbench终端执行：

```bash
# 检查服务状态
systemctl status video-server
```

**如果又进入less分页器**，按 `q` 退出。

**或者使用 `--no-pager` 选项**：

```bash
systemctl status video-server --no-pager
```

---

### 步骤3：检查端口监听

```bash
# 检查8081端口是否在监听
netstat -tlnp | grep 8081
```

**应该看到**：`0.0.0.0:8081` 或 `:::8081`

---

### 步骤4：测试服务器API

```bash
# 测试视频列表API
curl http://localhost:8081/api/list/原创视频

# 测试歌曲列表API
curl http://localhost:8081/api/list/原创歌曲
```

**应该返回**：`[]`（空数组）

---

## 📋 完整操作流程

### 在Workbench终端执行：

1. **按 `q` 退出less**

2. **检查服务状态**（使用 `--no-pager` 避免进入分页器）：
```bash
systemctl status video-server --no-pager
```

3. **检查端口监听**：
```bash
netstat -tlnp | grep 8081
```

4. **测试API**：
```bash
curl http://localhost:8081/api/list/原创视频
curl http://localhost:8081/api/list/原创歌曲
```

---

## 💡 提示

- **如果命令输出很长**，使用 `--no-pager` 选项避免进入分页器
- **如果已经进入分页器**，按 `q` 退出
- **查看日志时**，使用 `-n 10` 限制行数：`journalctl -u video-server -n 10 --no-pager`

---

## 🎯 现在可以执行

1. **按 `q` 退出less**
2. **执行检查命令**（使用 `--no-pager` 选项）

---

**先按 `q` 退出less，然后执行检查命令！** ⌨️

