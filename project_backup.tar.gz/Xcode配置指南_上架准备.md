# 📱 Xcode配置指南 - 上架准备

## 🎯 项目信息

- **Flutter项目名称**：`video_music_app`
- **iOS显示名称**：`影音播放器`
- **Bundle ID**：`com.example.videoMusicApp`（需要修改为唯一ID）
- **当前版本**：1.0.0+1

---

## ⚠️ 重要：统一项目名称

### 当前状态
- ✅ Flutter项目：`video_music_app`
- ✅ iOS显示名称：`影音播放器`
- ⚠️ Bundle ID：`com.example.videoMusicApp`（需要修改）

### 需要修改的Bundle ID

**上架App Store需要唯一的Bundle ID**，格式：`com.你的域名.应用名`

**建议修改为**：
- `com.shiian.videomusicapp`（使用你的域名）
- 或 `com.yourname.videomusicapp`

---

## 🔧 Xcode配置步骤

### 步骤1：打开Xcode项目

```bash
cd /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905
open ios/Runner.xcworkspace
```

### 步骤2：配置签名和Bundle ID

1. **在Xcode中**：
   - 选择左侧的 `Runner` 项目
   - 选择 `Runner` target
   - 点击 `Signing & Capabilities` 标签

2. **修改Bundle Identifier**：
   - 将 `com.example.videoMusicApp` 改为 `com.shiian.videomusicapp`
   - 或使用你的唯一标识

3. **选择Team**：
   - 选择你的Apple Developer账号
   - 如果没有，点击"Add Account"添加

4. **自动签名**：
   - 确保勾选 "Automatically manage signing"
   - Xcode会自动生成证书和配置文件

### 步骤3：配置应用信息

1. **General标签**：
   - Display Name: `影音播放器`（已设置）
   - Version: `1.0.0`
   - Build: `1`

2. **Info标签**：
   - 检查 `Info.plist` 中的配置
   - 确保权限说明已添加

---

## 📱 iOS真机测试配置

### 步骤1：连接iPhone

1. 用USB线连接iPhone和Mac
2. 在iPhone上点击"信任此电脑"

### 步骤2：在Xcode中选择设备

1. 打开 `ios/Runner.xcworkspace`
2. 在顶部工具栏选择你的iPhone作为目标设备
3. 确保Team已选择

### 步骤3：运行应用

```bash
cd /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905
flutter run -d ios
```

**或者直接在Xcode中**：
- 点击运行按钮（▶️）
- 或按 `Cmd+R`

---

## 🤖 Android真机测试配置

### 步骤1：连接Android手机

1. 启用USB调试：
   - 设置 → 关于手机 → 连续点击"版本号"7次
   - 返回设置 → 开发者选项 → 启用"USB调试"

2. 连接手机：
   - USB线连接手机和Mac
   - 手机上确认"允许USB调试"

### 步骤2：检查连接

```bash
adb devices
```

应该看到你的设备ID和"device"状态

### 步骤3：运行应用

```bash
cd /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905
flutter run -d android
```

---

## 📋 上架前检查清单

### iOS上架检查

- [ ] Bundle ID已修改为唯一ID（不是com.example.*）
- [ ] Team已选择（Apple Developer账号）
- [ ] 应用图标已设置
- [ ] 启动画面已配置
- [ ] 权限说明已添加（相册、网络等）
- [ ] 版本号已设置（1.0.0）
- [ ] 真机测试通过
- [ ] 所有功能正常

### Android上架检查

- [ ] 应用图标已设置
- [ ] 包名已设置（com.example.video_music_app）
- [ ] 版本号已设置（versionCode和versionName）
- [ ] 签名配置已完成
- [ ] 权限已声明
- [ ] 真机测试通过
- [ ] 所有功能正常

---

## 🔄 修改Bundle ID的完整步骤

### 在Xcode中修改：

1. 打开 `ios/Runner.xcworkspace`
2. 选择 `Runner` → `Signing & Capabilities`
3. 修改 `Bundle Identifier` 为 `com.shiian.videomusicapp`
4. 选择你的Team
5. 保存

### 在代码中修改（如果需要）：

```bash
# 修改Info.plist（通常不需要，Xcode会自动更新）
# 但可以检查
grep -r "com.example" ios/
```

---

## 🚀 快速测试命令

### iOS真机测试
```bash
cd /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905
flutter devices
flutter run -d ios
```

### Android真机测试
```bash
cd /Volumes/Expansion/FlutterProjects/桌面影音播放器_安装包_20251121_165905
adb devices
flutter run -d android
```

---

## 📝 当前配置状态

- ✅ 项目名称：video_music_app
- ✅ 显示名称：影音播放器
- ⚠️ Bundle ID：com.example.videoMusicApp（需要修改）
- ✅ 服务器：47.243.177.166:8081
- ✅ Git版本：fb56977

---

**下一步**：
1. 修改Bundle ID为唯一标识
2. 配置Apple Developer账号
3. 进行真机测试
4. 准备上架


