# 启动服务器并测试API

## ✅ URL解码测试结果

- ✅ URL编码/解码逻辑正确
- ✅ 代码逻辑正确（能扫描到9个文件）
- ❌ 服务器没有运行（Connection refused）

---

## 🚀 步骤1：启动服务器并测试

### 方法1：后台运行（推荐）

```bash
# 启动服务器（后台运行，输出到日志）
cd /root/video_server
python3 video_server.py > /tmp/video_server.log 2>&1 &

# 等待服务器启动
sleep 2

# 测试API（使用URL编码）
curl "http://localhost:8081/api/list/$(python3 -c "from urllib.parse import quote; print(quote('原创视频'))")"

# 查看服务器日志（调试信息）
cat /tmp/video_server.log
```

---

### 方法2：使用systemd服务

```bash
# 启动服务
systemctl start video-server

# 等待启动
sleep 2

# 测试API
curl "http://localhost:8081/api/list/$(python3 -c "from urllib.parse import quote; print(quote('原创视频'))")"

# 查看日志
journalctl -u video-server -n 50 --no-pager
```

---

## 🔍 步骤2：查看调试信息

执行上面的命令后，应该看到：
- API返回的JSON结果
- 服务器日志中的调试信息（原始路径、解码后的category等）

---

## 📋 执行后

把以下内容发给我：
1. **API返回的JSON结果**
2. **服务器日志中的调试信息**

---

**先启动服务器，然后测试API！** 🚀

