//
//  videoMusicAppTests.swift
//  videoMusicAppTests
//
//  Created by Xiaohui Hu on 2025/11/24.
//

import Testing
@testable import videoMusicApp

struct videoMusicAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
