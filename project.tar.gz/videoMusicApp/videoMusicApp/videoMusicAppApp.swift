//
//  videoMusicAppApp.swift
//  videoMusicApp
//
//  Created by Xiaohui Hu on 2025/11/24.
//

import SwiftUI

@main
struct videoMusicAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
